// local variable

 function square(){

     var a=10; // local variable

     console.log(a*a);// square of a 

 }
 square();